#!/sbin/sh
#====================================================
#              FILE: set_prop.sh
#            AUTHOR: xpirt
#       DESCRIPTION: Change prop in file
#====================================================

# UKAzXDA Use
FILE=/tmp/repartition.sh
prop=$1
arg=$2
concat="${prop}="

if grep -Fq $prop $FILE ; then
    sed -i "/$concat/c $prop=$arg" "$FILE"
    echo "to $prop set value $arg in build.prop"   
else
    echo "$prop does not exist in build.prop"   
    echo "appending to end of build.prop"
    echo $prop=$arg >> $FILE
fi;
